#!/usr/bin/env python2
from urllib import urlopen
import argparse
import random

arg_parser = argparse.ArgumentParser()
arg_parser.add_argument("-i",
                       "--input",
                       dest="berkas",
                       action="store",
                       default=None,
                        required=True,
                        help="ID PerpusIndo (perpusindo.info/berkas/*idberkas*)")
args = arg_parser.parse_args()

pi = 'http://perpusindo.info/berkas/' + args.berkas

try: 
	an = 1
	while True:
		an += 1
		proses = urlopen(pi)
		x = random.randint(1,3)
		for delete in range (1): 
			print"Tambah",x,"XP","  (Kayaknya)"
except KeyboardInterrupt:
	print('Proses Terganggu! Menghentikan Proses!')