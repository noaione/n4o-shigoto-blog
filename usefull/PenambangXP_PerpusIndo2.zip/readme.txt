> Yang Diperlukan
- Python 2.7 (https://www.python.org/ftp/python/2.7.14/python-2.7.14.msi)

> Cara menggunakan
- Cukup masukan ID berkas PerpusIndo untuk Mulai
- Cara menghentikan dengan menutup window atau CTRL+C

> Apa itu ID Berkas
Misalkan ada link seperti
http://www.perpusindo.info/berkas/abcdefg

Nah, "abcdefg" itu adalah ID berkas yang nanti akan di input