#!/usr/bin/env python2
from modulefinder import ModuleFinder

import re, itertools

try:
    import numpy as np
except ImportError:
    pass

try:
    import cv2 as cv
except ImportError:
    pass
	
try:
    from matplotlib import pyplot as plt
except ImportError:
    pass
	
try:
    import argparse
except ImportError:
    pass

#import numpy as np
#import cv2 as cv
#from matplotlib import pyplot as plt
#import argparse

arg_parser = argparse.ArgumentParser()
arg_parser.add_argument("-i",
                       "--input",
                       dest="input",
                       action="store",
                       default=None,
                        required=True,
                        help="Input picture (with extension, ex: 123.png)")
args = arg_parser.parse_args()

try:
	img = cv.imread(args.input,0)
	edges = cv.Canny(img,50,200)

	plt.subplot(121),plt.imshow(img,cmap = 'gray')
	plt.title('Original Image'), plt.xticks([]), plt.yticks([])
	plt.subplot(122),plt.imshow(edges,cmap = 'gray')
	plt.title('Edge Image'), plt.xticks([]), plt.yticks([])
	plt.show()
	
except:
	print'input',args.input,'is not found or wrong, please refer to canny.py -h'