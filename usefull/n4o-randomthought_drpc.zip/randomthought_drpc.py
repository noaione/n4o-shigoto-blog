try:
	from pypresence import Presence
	import time
	import random
	import urllib.request
	import re
	from bs4 import BeautifulSoup
except Exception:
	print('Missing dependencies, try to run installdep.bat')
	sys.exit(0)

class ClientURL(urllib.request.FancyURLopener):
    version = "Mozilla/5.0"

opener = ClientURL()

def getthought():
    link = "https://vichaar.herokuapp.com/random"
    halaman = opener.open(link)
    soup = BeautifulSoup(halaman, 'html.parser')
    soup = str(soup)
    asd = re.sub(r'.*"vichaar":', '', soup)
    vichaa = '"vichaarak"'
    vichaarak = asd.find(vichaa)
    lengthasd = len(asd)
    deletethismuch = (lengthasd - vichaarak) * -1
    deletenow = asd[:deletethismuch]
    deletenow2 = deletenow[1:]
    finished = deletenow2[:-2]
    return finished

bot_id = "441970827412373505" #maybe change this to your client id
RPC = Presence(bot_id)
RPC.connect()

while True:
    thought = getthought()
    thought = str(thought)
    length1 = len(thought)
    while length1 > 127:
        print('Text is beyond 127 character, changing')
        print('')
        thought = ''
        thought = getthought()
        lenth = len(thought)
        if lenth < 127:
            thought = str(thought)
            break
    asdf = RPC.update(state=thought, details="Thinking about life...", large_image="main")
    print('Thinking about: ' + thought)
    print(asdf)
    print('')
    time.sleep(15)